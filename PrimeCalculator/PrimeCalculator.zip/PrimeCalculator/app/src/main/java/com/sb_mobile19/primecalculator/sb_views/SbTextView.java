package com.sb_mobile19.primecalculator.sb_views;


import android.content.Context;
import android.util.AttributeSet;


public class SbTextView extends android.support.v7.widget.AppCompatTextView {
    public SbTextView(Context context) {
        super(context);
    }

    public SbTextView(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
