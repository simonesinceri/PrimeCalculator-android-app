package com.sb_mobile19.primecalculator.threads;

import android.app.Activity;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;

import com.sb_mobile19.primecalculator.MainActivity;
import com.sb_mobile19.primecalculator.R;
import com.sb_mobile19.primecalculator.sb_views.SbTextView;

import java.lang.ref.WeakReference;
import java.lang.String;


public class CalculatorTask extends AsyncTask<Object, Long, String> {

    private final String TAG = "ASYNC_TASK_CALCULATOR";
    private Long ZERO = new Long(0);
    private Long UNO = new Long(1);
    private Long DUE = new Long(2);
    private Long TRE = new Long(3);


    private final WeakReference<Activity> activity;

    public CalculatorTask(Activity a) {
        this.activity = new WeakReference<>(a);
    }

    @Override
    protected String doInBackground(Object... objects) {

        String result = "" ;
        String cmd = (String) objects[1];


        if (cmd.compareTo("#prime") == 0)
            result = String.valueOf(calcoloPrimi((Long) objects[0]));

        if (cmd.compareTo("prime") == 0) {
            if (verificaPrimo((Long) objects[0]))
                result = "True";
            else
                result ="False" ;
        }

        if (cmd.compareTo("twin") == 0) {
            if((Long)objects[0] != 0)
                result = primiGemelli((Long) objects[0]);
            else
                result = "";

        }

        if (cmd.compareTo("euler") == 0) {
            result = String.valueOf(funzioneEulero((Long) objects[0]));

        }
        if (cmd.compareTo("factor") == 0)
            result = fattorizzazione((Long) objects[0]);

        if (cmd.compareTo("Nprimo") == 0)
            if((Long)objects[0] != 0)
                result = String.valueOf(nNumeroPrimo((Long) objects[0]));
            else
                result = "";


        return result;
    }

    @Override
    protected void onPreExecute() {
        Log.w(TAG, "Start");
        activity.get().findViewById(R.id.sbBtnStop).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnPrime).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnEuler).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnNumberPrime).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnNthPrime).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnTwin).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnFact).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn0).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn1).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn2).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn3).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn4).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn5).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn6).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn7).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn8).setEnabled(false);
        activity.get().findViewById(R.id.sbBtn9).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnCanc).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnClear).setEnabled(false);


        ((SbTextView) activity.get().findViewById(R.id.tvResult))
                .setText("");
        ((ProgressBar) activity.get().findViewById(R.id.pbCirc))
                .setVisibility(View.VISIBLE);
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        Log.w(TAG, "Result" + s);
        activity.get().findViewById(R.id.sbBtnStop).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnEuler).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnNumberPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnNthPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnTwin).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnFact).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn0).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn1).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn2).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn3).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn4).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn5).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn6).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn7).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn8).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn9).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnCanc).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnClear).setEnabled(true);

        ((SbTextView) activity.get().findViewById(R.id.tvResult))
                .setText(s);

        ((ProgressBar) activity.get().findViewById(R.id.pbCirc))
                .setVisibility(View.GONE);

        super.onPostExecute(s);
    }




    @Override
    protected void onCancelled(String s) {
        Log.w(TAG,"Deleted" + s);
        super.onCancelled(s);

        activity.get().findViewById(R.id.sbBtnStop).setEnabled(false);
        activity.get().findViewById(R.id.sbBtnPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnEuler).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnNumberPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnNthPrime).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnTwin).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnFact).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn0).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn1).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn2).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn3).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn4).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn5).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn6).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn7).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn8).setEnabled(true);
        activity.get().findViewById(R.id.sbBtn9).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnCanc).setEnabled(true);
        activity.get().findViewById(R.id.sbBtnClear).setEnabled(true);


        ((SbTextView) activity.get().findViewById(R.id.tvResult))
                .setText("");
        ((ProgressBar) activity.get().findViewById(R.id.pbCirc))
                .setVisibility(View.GONE);

    }

    //Verifica se n è primo

    boolean verificaPrimo(Long n) {

        Long i = DUE;
        Long e = new Long((int)Math.sqrt(n))+1;

        if (n < DUE)
            return false;

        for (; i < e; i++) {

            if (isCancelled())
                break;

            if (n % i == 0) {
                return false;
            }

        }
        return true;
    }


    // Restituisce quanti sono i numeri primi minori di n

    Long calcoloPrimi(Long n) {

        Long contPrimi = ZERO;
        Long i = UNO;

        while (i <= n) {

            if (isCancelled())
                break;

            if (verificaPrimo(i)) {
                contPrimi++;
            }

            i++;
        }
        return contPrimi;
    }



    /*
   restituisce quanti sono i numeri coprimi(MCD=1) con n
    */
    Long funzioneEulero(Long num) {
        Long count = ZERO;
        for (Long a = UNO; a < num; a++) {

            if (isCancelled())
                break;

            if (MCD(num, a) == 1) {
                count++;
            }
        }
        return count;
    }

    // Restituisce MCD tra a e b

    Long MCD(Long a, Long b) {
        Long temp;
        if (a < b) {
            temp = a;
            a = b;
            b = temp;
        }
        if (a % b == 0) {
            return b;
        }
        return (MCD(a % b, b));
    }

    /*
    Ritorna il nr scomposto nel prodotto di numeri primi
     */
     String fattorizzazione(Long n) {

         String risParziale = "";
         Long i = DUE;

         while (i <= n) {

             if (isCancelled())
                 break;

             if (n % i == 0) {
                 risParziale = risParziale + i + " ";
                 n /= i;
             } else {
                 i++;
             }
         }

         return risParziale;
     }



     /*
    coppia di primi gemelli(la differenza tra due numeri primi deve essere 2)
    Dato un nr n,la funzione restitusce l'n.ma coppia di primi gemelli
     */

    String primiGemelli(Long n) {
        String ris = "";
        Long coppieTrovate = ZERO;
        Long decrem = UNO;
        Long i = TRE;
        Long equals = DUE;


        while (coppieTrovate < n) {

            if (isCancelled())
                break;

            if (Math.abs(generaPrimo(i) - generaPrimo(i - decrem)) == equals) {
                coppieTrovate++;
            }

            i++;

        }
         return  ris = "(" + String.valueOf(generaPrimo(i - 2)) + "," + String.valueOf(generaPrimo(i - 1)) + ")";


    }

    //Genera numero primo <= n

    Long generaPrimo(Long n) {
        for (Long i = n; i > 0; i--) {
            if (verificaPrimo(i)) {
                return i;
            }

        }
        return UNO;
    }

    // Restituisce n-esimo primo

     Long nNumeroPrimo(Long n){

        Long cont = ZERO;

        for (Long i = UNO; i>0; i++){

            if (isCancelled())
                break;

            if (verificaPrimo(i)){
                cont++;

                if (cont == n)
                    return i;

            }

        }
        return ZERO;
    }
}

