package com.sb_mobile19.primecalculator.sb_views;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Button;

public class SbButton extends android.support.v7.widget.AppCompatButton {


    public SbButton(Context context) {
        super(context);
    }

    public SbButton(Context context, AttributeSet attrs) {
        super(context, attrs);
    }
}
