package com.sb_mobile19.primecalculator;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.sb_mobile19.primecalculator.sb_views.SbButton;
import com.sb_mobile19.primecalculator.sb_views.SbTextView;
import com.sb_mobile19.primecalculator.threads.CalculatorTask;

public class MainActivity extends AppCompatActivity
        implements View.OnClickListener {

    CalculatorTask ct;



    private SbTextView tvInput;
    private SbTextView tvResult;
    private ProgressBar pbCirc;

    private SbButton btn0;
    private SbButton btn1;
    private SbButton btn2;
    private SbButton btn3;
    private SbButton btn4;
    private SbButton btn5;
    private SbButton btn6;
    private SbButton btn7;
    private SbButton btn8;
    private SbButton btn9;
    private SbButton btnCanc;
    private  SbButton btnClear;

    private SbButton btnFact;
    private SbButton btnEuler;
    private SbButton btnNumberPrime;
    private SbButton btnPrime;
    private SbButton btnTwin;
    private SbButton btnNthPrime;
    private SbButton btnStop;


    private String input = "";
    private int count = 0;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvInput = findViewById(R.id.tvInput);
        tvResult = findViewById(R.id.tvResult);
        pbCirc  = findViewById(R.id.pbCirc);

        pbCirc.setVisibility(View.GONE);

        //customizzazione font edit text tipo display
        Typeface custom_font = Typeface.createFromAsset(getAssets(),  "Display.ttf");
        tvInput.setTypeface(custom_font);
        tvResult.setTypeface(custom_font);



        btn0 = findViewById(R.id.sbBtn0);
        btn1 = findViewById(R.id.sbBtn1);
        btn2 = findViewById(R.id.sbBtn2);
        btn3 = findViewById(R.id.sbBtn3);
        btn4 = findViewById(R.id.sbBtn4);
        btn5 = findViewById(R.id.sbBtn5);
        btn6 = findViewById(R.id.sbBtn6);
        btn7 = findViewById(R.id.sbBtn7);
        btn8 = findViewById(R.id.sbBtn8);
        btn9 = findViewById(R.id.sbBtn9);
        btnCanc = findViewById(R.id.sbBtnCanc);
        btnClear = findViewById(R.id.sbBtnClear);

        btnFact = findViewById(R.id.sbBtnFact);
        btnEuler = findViewById(R.id.sbBtnEuler);
        btnNumberPrime = findViewById(R.id.sbBtnNumberPrime);
        btnPrime = findViewById(R.id.sbBtnPrime);
        btnTwin = findViewById(R.id.sbBtnTwin);
        btnNthPrime = findViewById(R.id.sbBtnNthPrime);
        btnStop = findViewById(R.id.sbBtnStop);

        btn0.setOnClickListener(this);
        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);
        btn4.setOnClickListener(this);
        btn5.setOnClickListener(this);
        btn6.setOnClickListener(this);
        btn7.setOnClickListener(this);
        btn8.setOnClickListener(this);
        btn9.setOnClickListener(this);
        btnCanc.setOnClickListener(this);
        btnClear.setOnClickListener(this);

        btnFact.setOnClickListener(this);
        btnEuler.setOnClickListener(this);
        btnNumberPrime.setOnClickListener(this);
        btnPrime.setOnClickListener(this);
        btnTwin.setOnClickListener(this);
        btnNthPrime.setOnClickListener(this);
        btnStop.setOnClickListener(this);

        btnStop.setEnabled(false);

    }


    @Override
    public void onClick(View v) {

        int len = input.length();
        if(len < 20) {
            if (v.getId() == btn0.getId()) {

                input = input + "0";
                tvInput.setText(input);
            }

            if (v.getId() == btn1.getId()) {
                input = input + "1";
                tvInput.setText(input);
            }

            if (v.getId() == btn2.getId()) {
                input = input + "2";
                tvInput.setText(input);
            }

            if (v.getId() == btn3.getId()) {
                input = input + "3";
                tvInput.setText(input);
            }
            if (v.getId() == btn4.getId()) {
                input = input + "4";
                tvInput.setText(input);
            }

            if (v.getId() == btn5.getId()) {
                input = input + "5";
                tvInput.setText(input);
            }

            if (v.getId() == btn6.getId()) {
                input = input + "6";
                tvInput.setText(input);
            }

            if (v.getId() == btn7.getId()) {
                input = input + "7";
                tvInput.setText(input);
            }

            if (v.getId() == btn8.getId()) {
                input = input + "8";
                tvInput.setText(input);
            }

            if (v.getId() == btn9.getId()) {
                input = input + "9";
                tvInput.setText(input);
            }
        }else
            tvInput.setText("Error");

        if (v.getId() == btnCanc.getId()) {

            if(len == 0)
                tvInput.setText("");
            else {
                input = input.substring(0, len - 1);
                tvInput.setText(input);
                tvResult.setText("");
            }
        }
        if(v.getId() == btnClear.getId()){
            input = "";
            tvInput.setText("");
            tvResult.setText("");
        }



        if (v.getId() == R.id.sbBtnNumberPrime) {
            if((len != 0) && (len < 20)){
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "#prime");

            }
        }

        if (v.getId() == R.id.sbBtnPrime){
            if((len != 0) && (len < 20)){
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "prime");

            }
        }

        if (v.getId() == R.id.sbBtnTwin){
            if((len != 0) && (len < 20)){
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "twin");

            }
        }
        if (v.getId() == R.id.sbBtnEuler) {
            if((len != 0) && (len < 20)) {
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "euler");

            }
        }

        if (v.getId() == R.id.sbBtnFact) {
            if((len != 0) && (len < 20)) {
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "factor");

            }
        }

        if (v.getId() == R.id.sbBtnNthPrime) {
            if((len != 0) && (len < 20)) {
                ct = new CalculatorTask(this);
                Long value = Long.parseLong(tvInput.getText().toString());
                ct.execute(value, "Nprimo");

            }
        }



        if (v.getId() == R.id.sbBtnStop) {
            if (ct.getStatus() == AsyncTask.Status.RUNNING) {
                ct.cancel(true);

            }

        }
    }

}


